-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 3306
-- Database : jxmanager
-- 
-- Part : #1
-- Date : 2016-06-29 10:44:10
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `jx_action`
-- -----------------------------
DROP TABLE IF EXISTS `jx_action`;
CREATE TABLE `jx_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text COMMENT '行为规则',
  `log` text COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';


-- -----------------------------
-- Table structure for `jx_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `jx_action_log`;
CREATE TABLE `jx_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';


-- -----------------------------
-- Table structure for `jx_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `jx_auth_extend`;
CREATE TABLE `jx_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';


-- -----------------------------
-- Table structure for `jx_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `jx_auth_group`;
CREATE TABLE `jx_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL DEFAULT '' COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `jx_auth_group`
-- -----------------------------
INSERT INTO `jx_auth_group` VALUES ('16', 'admin', '1', '业务经理', '业务及跟单主管', '1', '');
INSERT INTO `jx_auth_group` VALUES ('14', 'admin', '1', '业务', '业务员', '1', '');
INSERT INTO `jx_auth_group` VALUES ('15', 'admin', '1', '跟单', '业务跟单', '1', '');
INSERT INTO `jx_auth_group` VALUES ('17', 'admin', '1', '跟单经理', '跟单主管', '1', '');
INSERT INTO `jx_auth_group` VALUES ('18', 'admin', '1', '总经理', '总经理', '1', '');

-- -----------------------------
-- Table structure for `jx_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `jx_auth_group_access`;
CREATE TABLE `jx_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `jx_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `jx_auth_rule`;
CREATE TABLE `jx_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=252 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `jx_auth_rule`
-- -----------------------------
INSERT INTO `jx_auth_rule` VALUES ('217', 'admin', '2', 'Admin/Index/index', '办公桌', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('218', 'admin', '1', 'Admin/Index/todo', '待办', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('219', 'admin', '1', 'Admin/offcialFlow/index', '公文流转', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('220', 'admin', '1', 'Admin/files/index', '归档文件', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('221', 'admin', '1', 'Admin/order/index', '订单管理', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('222', 'admin', '1', 'Admin/dataDig/index', '数据挖掘', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('223', 'admin', '1', 'Admin/basedata/index', '基础数据', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('224', 'admin', '1', 'Admin/calendar/index', '日程', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('225', 'admin', '2', 'Admin/flow/index', '工作流', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('226', 'admin', '1', 'Admin/coordinationFlow/index', '任务协同', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('227', 'admin', '1', 'Admin/Atlas/index', '产品图册', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('228', 'admin', '1', 'Admin/purchase/index', '采购管理', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('229', 'admin', '1', 'Admin/dataAggregate/index', '数据聚合', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('230', 'admin', '1', 'Admin/config/index', '系统设置', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('231', 'admin', '1', 'Admin/inbox/index', '邮件', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('232', 'admin', '1', 'Admin/otherFlow/index', '其他事项', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('233', 'admin', '2', 'Admin/Knowledge/index', '知识库', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('234', 'admin', '1', 'Admin/Information/index', '行业资讯', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('235', 'admin', '1', 'Admin/sample/index', '样品管理', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('236', 'admin', '1', 'Admin/dataAnalysis/index', '数据分析', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('237', 'admin', '1', 'Admin/user/index', '用户管理', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('238', 'admin', '1', 'Admin/Index/addr', '通讯录', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('239', 'admin', '1', 'Admin/flow/monitor', '流程监控', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('240', 'admin', '2', 'Admin/bussiness/index', '业务流', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('241', 'admin', '1', 'Admin/product/index', '生产管理', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('242', 'admin', '1', 'Admin/auth/index', '权限管理', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('243', 'admin', '1', 'Admin/docs/index', '文件柜', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('244', 'admin', '1', 'Admin/warehousing/index', '仓储管理', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('245', 'admin', '2', 'Admin/Bi/index', '商业智能', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('246', 'admin', '1', 'Admin/database/index', '数据库管理', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('247', 'admin', '2', 'Admin/System/index', '系统管理', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('248', 'admin', '1', 'Admin/profile/index', '个人中心', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('249', 'admin', '1', 'Admin/menu/add', '新增', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('250', 'admin', '1', 'Admin/menu/index', '菜单管理', '1', '');
INSERT INTO `jx_auth_rule` VALUES ('251', 'admin', '1', 'Admin/config/edit', '编辑', '1', '');

-- -----------------------------
-- Table structure for `jx_calendar`
-- -----------------------------
DROP TABLE IF EXISTS `jx_calendar`;
CREATE TABLE `jx_calendar` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '日程id',
  `title` varchar(255) DEFAULT NULL COMMENT '日程标题',
  `contents` varchar(255) DEFAULT NULL COMMENT '日程内容',
  `start` timestamp NULL DEFAULT NULL COMMENT '日程起',
  `end` timestamp NULL DEFAULT NULL COMMENT '日程止',
  `allday` tinyint(1) DEFAULT NULL COMMENT '是否全天',
  `color` varchar(8) DEFAULT NULL COMMENT '日程颜色',
  `st` varchar(5) DEFAULT NULL,
  `et` varchar(5) DEFAULT NULL,
  `uid` int(5) NOT NULL COMMENT '日程发起人',
  `gid` int(5) DEFAULT '0' COMMENT '共享组',
  `sharekey` tinyint(1) DEFAULT '1' COMMENT '是否共享',
  `status` tinyint(2) DEFAULT '1' COMMENT '日程状态',
  `col1` varchar(255) DEFAULT NULL COMMENT '预留',
  `col2` varchar(255) DEFAULT NULL COMMENT '预留',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `jx_calendar`
-- -----------------------------
INSERT INTO `jx_calendar` VALUES ('1', 'ymf', '', '2016-05-01 00:00:00', '2016-05-02 00:00:00', '1', '#e61c23', '', '', '1', '0', '1', '1', '', '');
INSERT INTO `jx_calendar` VALUES ('2', 'ryan', '', '2016-05-03 00:00:00', '2016-05-05 00:00:00', '1', '', '', '', '1', '0', '1', '1', '', '');
INSERT INTO `jx_calendar` VALUES ('5', 'a', '', '2016-06-30 00:00:00', '2016-07-01 00:00:00', '', '#db913d', '', '', '1', '0', '1', '1', '', '');
INSERT INTO `jx_calendar` VALUES ('21', 'rainyian', '', '2016-05-16 00:00:00', '2016-05-17 00:00:00', '1', '#1c23e6', '', '', '1', '0', '1', '1', '', '');
INSERT INTO `jx_calendar` VALUES ('28', '测试   ', '', '2016-05-10 00:00:00', '2016-05-12 00:00:00', '1', '#3bdbdb', '', '', '1', '0', '1', '1', '', '');
INSERT INTO `jx_calendar` VALUES ('31', 'Sale CF', '', '2016-05-06 00:00:00', '2016-05-07 00:00:00', '1', '', '', '', '1', '0', '1', '1', '', '');
INSERT INTO `jx_calendar` VALUES ('32', '出货', '', '2016-05-26 00:00:00', '2016-05-27 00:00:00', '', '#3bdbdb', '', '', '1', '0', '1', '1', '', '');
INSERT INTO `jx_calendar` VALUES ('33', '测试   ', '', '2016-05-19 00:00:00', '2016-05-20 00:00:00', '', '#3bdbdb', '', '', '1', '0', '1', '1', '', '');
INSERT INTO `jx_calendar` VALUES ('35', 'Untitled Event  ', '', '2016-05-08 00:00:00', '2016-05-09 00:00:00', '1', '#db913d', '', '', '1', '0', '1', '1', '', '');
INSERT INTO `jx_calendar` VALUES ('36', 'Untitled Event', '', '2016-05-22 00:00:00', '2016-05-23 00:00:00', '', '', '', '', '1', '0', '1', '1', '', '');
INSERT INTO `jx_calendar` VALUES ('37', 'a ', '', '2016-05-15 00:00:00', '2016-05-16 00:00:00', '1', '#db3bc6', '', '', '1', '0', '1', '1', '', '');
INSERT INTO `jx_calendar` VALUES ('38', 'Untitled Event', '', '2016-05-02 00:00:00', '2016-05-03 00:00:00', '', '', '', '', '1', '0', '1', '1', '', '');
INSERT INTO `jx_calendar` VALUES ('39', 'Untitled Event', '', '2016-05-17 00:00:00', '2016-05-18 00:00:00', '', '', '', '', '1', '0', '1', '1', '', '');
INSERT INTO `jx_calendar` VALUES ('40', '36', '', '2016-05-24 18:00:00', '2016-05-25 00:00:00', '', '#db3bc6', '', '', '1', '0', '1', '1', '', '');

-- -----------------------------
-- Table structure for `jx_config`
-- -----------------------------
DROP TABLE IF EXISTS `jx_config`;
CREATE TABLE `jx_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '配置说明',
  `create_time` date NOT NULL DEFAULT '0000-00-00' COMMENT '创建时间',
  `update_time` date NOT NULL DEFAULT '0000-00-00' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `uid` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `jx_config`
-- -----------------------------
INSERT INTO `jx_config` VALUES ('47', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '', '仅超级管理员可访问的控制器方法', '2016-06-24', '2016-06-24', '1', '0:Admin/getMenus\n1:AuthManager/updateRules\n2:AuthManager/tree', '0', '1');
INSERT INTO `jx_config` VALUES ('48', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '', '', '2016-06-24', '2016-06-24', '1', '0:user/updatePassword\n1:user/updateNickname\n2:user/submitPassword\n3:user/submitNickname', '0', '1');
INSERT INTO `jx_config` VALUES ('49', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '3', '', '', '2016-06-24', '2016-06-24', '1', '0:数字\n1:字符\n2:文本\n3:数组\n4:枚举', '2', '1');
INSERT INTO `jx_config` VALUES ('50', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '2', '', '', '2016-06-24', '2016-06-24', '1', '1', '3', '1');
INSERT INTO `jx_config` VALUES ('51', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '3', '', '', '2016-06-24', '2016-06-24', '1', '20971520', '7', '1');
INSERT INTO `jx_config` VALUES ('52', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '3', '', '', '2016-06-24', '2016-06-24', '1', './Data/', '5', '1');
INSERT INTO `jx_config` VALUES ('53', 'WEB_SITE_KEYWORD', '2', '网站关键字', '0', '', '', '2016-06-24', '2016-06-24', '1', 'JX,JxManager', '8', '1');
INSERT INTO `jx_config` VALUES ('54', 'AUTH_CONFIG', '3', 'Auth配置', '3', '', '', '2016-06-24', '2016-06-24', '1', 'AUTH_ON:1\nAUTH_TYPE:2', '8', '1');
INSERT INTO `jx_config` VALUES ('55', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '3', '', '', '2016-06-24', '2016-06-24', '1', '1', '9', '1');
INSERT INTO `jx_config` VALUES ('56', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '3', '', '', '2016-06-24', '2016-06-24', '1', '9', '10', '1');
INSERT INTO `jx_config` VALUES ('57', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '3', '', '', '2016-06-24', '2016-06-24', '1', '', '12', '1');

-- -----------------------------
-- Table structure for `jx_datatables`
-- -----------------------------
DROP TABLE IF EXISTS `jx_datatables`;
CREATE TABLE `jx_datatables` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(250) NOT NULL DEFAULT '',
  `last_name` varchar(250) NOT NULL DEFAULT '',
  `position` varchar(250) NOT NULL DEFAULT '',
  `email` varchar(250) NOT NULL DEFAULT '',
  `office` varchar(250) NOT NULL DEFAULT '',
  `start_date` datetime DEFAULT NULL,
  `age` int(8) DEFAULT NULL,
  `salary` int(8) DEFAULT NULL,
  `seq` int(8) DEFAULT NULL,
  `extn` varchar(8) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `seq` (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `jx_datatables`
-- -----------------------------
INSERT INTO `jx_datatables` VALUES ('1', 'Tiger', 'Nixon', 'System Architect', 't.nixon@datatables.net', 'Edinburgh', '2011-04-25 00:00:00', '61', '320800', '2', '5421');
INSERT INTO `jx_datatables` VALUES ('3', 'Ashton', 'Cox', 'Junior Technical Author', 'a.cox@datatables.net', 'San Francisco', '2009-01-12 00:00:00', '66', '86000', '6', '1562');
INSERT INTO `jx_datatables` VALUES ('5', 'Airi', 'Satou', 'Accountant', 'a.satou@datatables.net', 'Tokyo', '2008-11-28 00:00:00', '33', '162700', '55', '5407');
INSERT INTO `jx_datatables` VALUES ('8', 'Rhona', 'Davidson', 'Integration Specialist', 'r.davidson@datatables.net', 'Tokyo', '2010-10-14 00:00:00', '55', '327900', '50', '6200');
INSERT INTO `jx_datatables` VALUES ('9', 'Colleen', 'Hurst', 'Javascript Developer', 'c.hurst@datatables.net', 'San Francisco', '2009-09-15 00:00:00', '39', '205500', '26', '2360');
INSERT INTO `jx_datatables` VALUES ('10', 'Sonya', 'Frost', 'Software Engineer', 's.frost@datatables.net', 'Edinburgh', '2008-12-13 00:00:00', '23', '103600', '18', '1667');
INSERT INTO `jx_datatables` VALUES ('11', 'Jena', 'Gaines', 'Office Manager', 'j.gaines@datatables.net', 'London', '2008-12-19 00:00:00', '30', '90560', '13', '3814');
INSERT INTO `jx_datatables` VALUES ('13', 'Charde', 'Marshall', 'Regional Director', 'c.marshall@datatables.net', 'San Francisco', '2008-10-16 00:00:00', '36', '470600', '14', '6741');
INSERT INTO `jx_datatables` VALUES ('15', 'Tatyana', 'Fitzpatrick', 'Regional Director', 't.fitzpatrick@datatables.net', 'London', '2010-03-17 00:00:00', '19', '385750', '54', '1965');
INSERT INTO `jx_datatables` VALUES ('16', 'Michael', 'Silva', 'Marketing Designer', 'm.silva@datatables.net', 'London', '2012-11-27 00:00:00', '66', '198500', '37', '1581');
INSERT INTO `jx_datatables` VALUES ('17', 'Paul', 'Byrd', 'Chief Financial Officer (CFO)', 'p.byrd@datatables.net', 'New York', '2010-06-09 00:00:00', '64', '725000', '32', '3059');
INSERT INTO `jx_datatables` VALUES ('18', 'Gloria', 'Little', 'Systems Administrator', 'g.little@datatables.net', 'New York', '2009-04-10 00:00:00', '59', '237500', '35', '1721');
INSERT INTO `jx_datatables` VALUES ('22', 'Yuri', 'Berry', 'Chief Marketing Officer (CMO)', 'y.berry@datatables.net', 'New York', '2009-06-25 00:00:00', '40', '675000', '57', '6154');
INSERT INTO `jx_datatables` VALUES ('24', 'Doris', 'Wilder', 'Sales Assistant', 'd.wilder@datatables.net', 'Sidney', '2010-09-20 00:00:00', '23', '85600', '56', '3023');
INSERT INTO `jx_datatables` VALUES ('25', 'Angelica', 'Ramos', 'Chief Executive Officer (CEO)', 'a.ramos@datatables.net', 'London', '2009-10-09 00:00:00', '47', '1200000', '36', '5797');
INSERT INTO `jx_datatables` VALUES ('26', 'Gavin', 'Joyce', 'Developer', 'g.joyce@datatables.net', 'Edinburgh', '2010-12-22 00:00:00', '42', '92575', '5', '8822');
INSERT INTO `jx_datatables` VALUES ('27', 'Jennifer', 'Chang', 'Regional Director', 'j.chang@datatables.net', 'Singapore', '2010-11-14 00:00:00', '28', '357650', '51', '9239');
INSERT INTO `jx_datatables` VALUES ('29', 'Fiona', 'Green', 'Chief Operating Officer (COO)', 'f.green@datatables.net', 'San Francisco', '2010-03-11 00:00:00', '48', '850000', '7', '2947');
INSERT INTO `jx_datatables` VALUES ('30', 'Shou', 'Itou', 'Regional Marketing', 's.itou@datatables.net', 'Tokyo', '2011-08-14 00:00:00', '20', '163000', '1', '8899');
INSERT INTO `jx_datatables` VALUES ('31', 'Michelle', 'House', 'Integration Specialist', 'm.house@datatables.net', 'Sidney', '2011-06-02 00:00:00', '37', '95400', '39', '2769');
INSERT INTO `jx_datatables` VALUES ('32', 'Suki', 'Burks', 'Developer', 's.burks@datatables.net', 'London', '2009-10-22 00:00:00', '53', '114500', '40', '6832');
INSERT INTO `jx_datatables` VALUES ('33', 'Prescott', 'Bartlett', 'Technical Author', 'p.bartlett@datatables.net', 'London', '2011-05-07 00:00:00', '27', '145000', '47', '3606');
INSERT INTO `jx_datatables` VALUES ('34', 'Gavin', 'Cortez', 'Team Leader', 'g.cortez@datatables.net', 'San Francisco', '2008-10-26 00:00:00', '22', '235500', '52', '2860');
INSERT INTO `jx_datatables` VALUES ('35', 'Martena', 'Mccray', 'Post-Sales support', 'm.mccray@datatables.net', 'Edinburgh', '2011-03-09 00:00:00', '46', '324050', '8', '8240');
INSERT INTO `jx_datatables` VALUES ('36', 'Unity', 'Butler', 'Marketing Designer', 'u.butler@datatables.net', 'San Francisco', '2009-12-09 00:00:00', '47', '85675', '24', '5384');
INSERT INTO `jx_datatables` VALUES ('37', 'Howard', 'Hatfield', 'Office Manager', 'h.hatfield@datatables.net', 'San Francisco', '2008-12-16 00:00:00', '51', '164500', '38', '7031');
INSERT INTO `jx_datatables` VALUES ('38', 'Hope', 'Fuentes', 'Secretary', 'h.fuentes@datatables.net', 'San Francisco', '2010-02-12 00:00:00', '41', '109850', '53', '6318');
INSERT INTO `jx_datatables` VALUES ('39', 'Vivian', 'Harrell', 'Financial Controller', 'v.harrell@datatables.net', 'San Francisco', '2009-02-14 00:00:00', '62', '452500', '30', '9422');
INSERT INTO `jx_datatables` VALUES ('40', 'Timothy', 'Mooney', 'Office Manager', 't.mooney@datatables.net', 'London', '2008-12-11 00:00:00', '37', '136200', '28', '7580');
INSERT INTO `jx_datatables` VALUES ('41', 'Jackson', 'Bradshaw', 'Director', 'j.bradshaw@datatables.net', 'New York', '2008-09-26 00:00:00', '65', '645750', '34', '1042');
INSERT INTO `jx_datatables` VALUES ('42', 'Olivia', 'Liang', 'Support Engineer', 'o.liang@datatables.net', 'Singapore', '2011-02-03 00:00:00', '64', '234500', '4', '2120');
INSERT INTO `jx_datatables` VALUES ('43', 'Bruno', 'Nash', 'Software Engineer', 'b.nash@datatables.net', 'London', '2011-05-03 00:00:00', '38', '163500', '3', '6222');
INSERT INTO `jx_datatables` VALUES ('44', 'Sakura', 'Yamamoto', 'Support Engineer', 's.yamamoto@datatables.net', 'Tokyo', '2009-08-19 00:00:00', '37', '139575', '31', '9383');
INSERT INTO `jx_datatables` VALUES ('45', 'Thor', 'Walton', 'Developer', 't.walton@datatables.net', 'New York', '2013-08-11 00:00:00', '61', '98540', '11', '8327');
INSERT INTO `jx_datatables` VALUES ('46', 'Finn', 'Camacho', 'Support Engineer', 'f.camacho@datatables.net', 'San Francisco', '2009-07-07 00:00:00', '47', '87500', '10', '2927');
INSERT INTO `jx_datatables` VALUES ('47', 'Serge', 'Baldwin', 'Data Coordinator', 's.baldwin@datatables.net', 'Singapore', '2012-04-09 00:00:00', '64', '138575', '44', '8352');
INSERT INTO `jx_datatables` VALUES ('48', 'Zenaida', 'Frank', 'Software Engineer', 'z.frank@datatables.net', 'New York', '2010-01-04 00:00:00', '63', '125250', '42', '7439');
INSERT INTO `jx_datatables` VALUES ('49', 'Zorita', 'Serrano', 'Software Engineer', 'z.serrano@datatables.net', 'San Francisco', '2012-06-01 00:00:00', '56', '115000', '27', '4389');
INSERT INTO `jx_datatables` VALUES ('50', 'Jennifer', 'Acosta', 'Junior Javascript Developer', 'j.acosta@datatables.net', 'Edinburgh', '2013-02-01 00:00:00', '43', '75650', '49', '3431');
INSERT INTO `jx_datatables` VALUES ('52', 'Hermione', 'Butler', 'Regional Director', 'h.butler@datatables.net', 'London', '2011-03-21 00:00:00', '47', '356250', '9', '1016');
INSERT INTO `jx_datatables` VALUES ('53', 'Lael', 'Greer', 'Systems Administrator', 'l.greer@datatables.net', 'London', '2009-02-27 00:00:00', '21', '103500', '25', '6733');
INSERT INTO `jx_datatables` VALUES ('54', 'Jonas', 'Alexander', 'Developer', 'j.alexander@datatables.net', 'San Francisco', '2010-07-14 00:00:00', '30', '86500', '33', '8196');
INSERT INTO `jx_datatables` VALUES ('55', 'Shad', 'Decker', 'Regional Director', 's.decker@datatables.net', 'Edinburgh', '2008-11-13 00:00:00', '51', '183000', '43', '6373');
INSERT INTO `jx_datatables` VALUES ('56', 'Michael', 'Bruce', 'Javascript Developer', 'm.bruce@datatables.net', 'Singapore', '2011-06-27 00:00:00', '29', '183000', '16', '5384');
INSERT INTO `jx_datatables` VALUES ('57', 'Donna', 'Snider', 'Customer Support', 'd.snider@datatables.net', 'New York', '2011-01-25 00:00:00', '27', '112000', '19', '4226');

-- -----------------------------
-- Table structure for `jx_member`
-- -----------------------------
DROP TABLE IF EXISTS `jx_member`;
CREATE TABLE `jx_member` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `nickname` varchar(6) DEFAULT NULL,
  `sex` varchar(6) DEFAULT NULL,
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL DEFAULT '' COMMENT '用户手机',
  `wx` char(10) DEFAULT NULL,
  `dept` varchar(10) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '用户状态',
  `reg_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `jx_member`
-- -----------------------------
INSERT INTO `jx_member` VALUES ('1', 'administrator', '超级管理员', 'male', '92f0d01b7ab33e69f3c2d793d8041ac4', 'admin@itpdc.com', '13415365691', 'yianyao', '总经办', '1', '2016-06-13 00:00:00', '0', '1467161441', '0', '0');
INSERT INTO `jx_member` VALUES ('2', 'yianyao', 'CTO', 'male', '92f0d01b7ab33e69f3c2d793d8041ac4', 'cto@itpdc.com', '13800138000', '', '总经办', '1', '2016-06-14 00:00:00', '0', '1466822718', '0', '0');

-- -----------------------------
-- Table structure for `jx_menu`
-- -----------------------------
DROP TABLE IF EXISTS `jx_menu`;
CREATE TABLE `jx_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `uid` tinyint(1) NOT NULL DEFAULT '1' COMMENT '创建用户',
  `class` varchar(20) DEFAULT NULL COMMENT '样式',
  `createTime` date NOT NULL COMMENT '创建日期',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `jx_menu`
-- -----------------------------
INSERT INTO `jx_menu` VALUES ('1', '办公桌', '0', '1', 'Index/index', '0', '', '', '0', '1', '1', 'icon-screen-desktop', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('2', '待办', '1', '1', 'Index/todo', '0', '', 'index', '0', '1', '1', 'icon-action-undo', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('3', '日程', '1', '2', 'calendar/index', '0', '', 'index', '0', '1', '1', 'icon-calendar', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('4', '邮件', '1', '3', 'inbox/index', '0', '', 'index', '0', '1', '1', 'icon-envelope', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('5', '通讯录', '1', '4', 'Index/addr', '0', '', 'index', '0', '1', '1', 'icon-envelope-letter', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('6', '文件柜', '1', '5', 'docs/index', '0', '', 'index', '0', '1', '1', 'icon-folder-alt', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('7', '工作流', '0', '3', 'flow/index', '0', '', '', '0', '1', '1', 'fa fa-bell', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('8', '系统管理', '0', '6', 'System/index', '0', '', '', '0', '1', '1', 'fa fa-bolt', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('9', '公文流转', '7', '1', 'offcialFlow/index', '0', '', 'flow', '0', '1', '1', 'fa fa-exchange', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('10', '任务协同', '7', '2', 'coordinationFlow/index', '0', '', 'flow', '0', '1', '1', 'fa fa-square', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('11', '其他事项', '7', '3', 'otherFlow/index', '0', '', 'flow', '0', '1', '1', 'fa fa-shield', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('12', '流程监控', '7', '4', 'flow/monitor', '0', '', 'flow', '0', '1', '1', 'fa fa-eye', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('13', '知识库', '0', '2', 'Knowledge/index', '0', '', '', '0', '1', '1', 'icon-wallet', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('14', '归档文件', '13', '1', 'files/index', '0', '', 'know', '0', '1', '1', 'icon-docs', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('15', '产品图册', '13', '2', 'Atlas/index', '0', '', 'know', '0', '1', '1', 'icon-picture', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('16', '行业资讯', '13', '3', 'Information/index', '0', '', 'know', '0', '1', '1', 'icon-bubbles', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('17', '业务流', '0', '4', 'bussiness/index', '0', '', '', '0', '1', '1', 'icon-target', '2016-06-23');
INSERT INTO `jx_menu` VALUES ('18', '订单管理', '17', '1', 'order/index', '0', '', 'bus', '0', '1', '1', 'icon-speedometer', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('19', '采购管理', '17', '2', 'purchase/index', '0', '', 'bus', '0', '1', '1', 'icon-calculator', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('20', '样品管理', '17', '3', 'sample/index', '0', '', 'bus', '0', '1', '1', 'icon-globe-alt', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('21', '生产管理', '17', '4', 'product/index', '0', '', 'bus', '0', '1', '1', 'icon-anchor', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('22', '仓储管理', '17', '5', 'warehousing/index', '0', '', 'bus', '0', '1', '1', 'icon-loop', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('23', '商业智能', '0', '5', 'Bi/index', '0', '', '', '0', '1', '1', 'icon-equalizer', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('24', '数据挖掘', '23', '1', 'dataDig/index', '0', '', 'bi', '0', '1', '1', 'icon-directions', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('25', '数据聚合', '23', '2', 'dataAggregate/index', '0', '', 'bi', '0', '1', '1', 'icon-grid', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('26', '数据分析', '23', '3', 'dataAnalysis/index', '0', '', 'bi', '0', '1', '1', 'icon-bar-chart', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('27', '基础数据', '8', '1', 'basedata/index', '0', '', 'sys', '0', '1', '1', 'icon-refresh', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('28', '系统设置', '8', '2', 'config/index', '0', '', 'sys', '0', '1', '1', 'icon-wrench', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('33', '新增', '28', '1', 'menu/add', '0', '', '', '0', '1', '1', '', '2016-06-17');
INSERT INTO `jx_menu` VALUES ('29', '用户管理', '8', '3', 'user/index', '0', '', 'sys', '0', '1', '1', 'icon-users', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('30', '权限管理', '8', '4', 'auth/index', '0', '', 'sys', '0', '1', '1', 'icon-power', '2016-06-14');
INSERT INTO `jx_menu` VALUES ('32', '数据库管理', '8', '6', 'database/index', '0', '', 'sys', '0', '1', '1', 'fa fa-database', '2016-06-23');
INSERT INTO `jx_menu` VALUES ('34', '个人中心', '8', '7', 'profile/index', '0', '', 'sys', '0', '1', '1', 'icon-user', '2016-06-23');
INSERT INTO `jx_menu` VALUES ('31', '菜单管理', '8', '5', 'menu/index', '0', '', 'sys', '0', '1', '1', 'icon-map', '2016-06-23');
INSERT INTO `jx_menu` VALUES ('37', '编辑', '28', '1', 'config/edit', '0', '', '', '0', '1', '1', '', '2016-06-27');

-- -----------------------------
-- Table structure for `jx_ucenter_admin`
-- -----------------------------
DROP TABLE IF EXISTS `jx_ucenter_admin`;
CREATE TABLE `jx_ucenter_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员用户ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '管理员状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='管理员表';


-- -----------------------------
-- Table structure for `jx_ucenter_app`
-- -----------------------------
DROP TABLE IF EXISTS `jx_ucenter_app`;
CREATE TABLE `jx_ucenter_app` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '应用ID',
  `title` varchar(30) NOT NULL COMMENT '应用名称',
  `url` varchar(100) NOT NULL COMMENT '应用URL',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '应用IP',
  `auth_key` varchar(100) NOT NULL DEFAULT '' COMMENT '加密KEY',
  `sys_login` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '同步登陆',
  `allow_ip` varchar(255) NOT NULL DEFAULT '' COMMENT '允许访问的IP',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '应用状态',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='应用表';


-- -----------------------------
-- Table structure for `jx_ucenter_setting`
-- -----------------------------
DROP TABLE IF EXISTS `jx_ucenter_setting`;
CREATE TABLE `jx_ucenter_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '设置ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型（1-用户配置）',
  `value` text NOT NULL COMMENT '配置数据',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='设置表';

